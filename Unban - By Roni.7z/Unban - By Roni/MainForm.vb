﻿Imports System.Console, xNet, System.Threading
Module MainForm
    Dim Random As New Random
    Dim ProxiesList As String() : Dim ProxiesListLine As Integer
    Dim Sent, Errors As Integer
    Dim Running As Boolean = False
    Dim Full_Name, Username, Email_Address, Proxies As String
    Sub Main()
        UpdateTitle()
        Line("Main", ConsoleColor.Red) : Write(" Unban | Version ") : ForegroundColor = ConsoleColor.Red : Write("1.1.0") : ForegroundColor = ConsoleColor.White : Write(vbNewLine + vbNewLine)
        Line("Main", ConsoleColor.Red) : Write(" Full Name: ") : ForegroundColor = ConsoleColor.Red : Full_Name = ReadLine() : ForegroundColor = ConsoleColor.White
        Line("Main", ConsoleColor.Red) : Write(" Username: ") : ForegroundColor = ConsoleColor.Red : Username = ReadLine() : ForegroundColor = ConsoleColor.White
        Line("Main", ConsoleColor.Red) : Write(" Email: ") : ForegroundColor = ConsoleColor.Red : Email_Address = ReadLine() : ForegroundColor = ConsoleColor.White
        Line("Main", ConsoleColor.Red) : Write(" Proxies [Yes/No]: ") : ForegroundColor = ConsoleColor.Red : Email_Address = ReadLine() : ForegroundColor = ConsoleColor.White
        If Proxies = "Yes" Or Proxies = "yes" Then
            Line("Main", ConsoleColor.Red) : Write(" Drag Proxy List: ") : ForegroundColor = ConsoleColor.Red : ProxiesList = IO.File.ReadAllLines(ReadLine.Replace("""", Nothing)) : ForegroundColor = ConsoleColor.White
        End If
        Write(vbNewLine) : Line("Unban", ConsoleColor.Red) : Write(" Started...")
        Running = True : Send() : CheckStatus(Username)
    End Sub
    Sub Send()
        While Running
            If Not RequestUnban(Full_Name, Username, Email_Address).contains("errorSummary") Then
                Sent += 1
            Else
                Errors += 1
            End If
            UpdateTitle()
            Thread.Sleep(2500)
        End While
    End Sub
    Function RequestUnban(Full_Name As String, Username As String, Email As String)
        Try
            Dim Response = ""
            Using Request As HttpRequest = New HttpRequest
                With Request
                    .IgnoreProtocolErrors = True
                    .UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"
                    .Referer = "https://help.instagram.com/contact/1652567838289083"
                    .AddParam("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                    .AddHeader("X-FB-LSD", "AVq5ERc-bFM")
                    .AddHeader("Accept-Language", "en-US")
                    .AddParam("jazoest", "2857")
                    .AddParam("lsd", "AVq5ERc-bFM")
                    .AddParam("AccountType", "Personal")
                    .AddParam("name", Full_Name)
                    .AddParam("Field1489970557888767", Username)
                    .AddParam("email", Email)
                    .AddParam("Field236858559849125_iso2_country_code", "")
                    .AddParam("Field236858559849125", "Saudi Arabia")
                    .AddParam("support_form_id", "1652567838289083")
                    .AddParam("support_form_hidden_fields", "{""904224879693114"":false,""495070633933955"":false,""1489970557888767"":false,""488955464552044"":false,""236858559849125"":false,""1638971086372158"":true,""1615324488732156"":true,""236548136468765"":true}")
                    .AddParam("support_form_fact_false_fields", "[]")
                    .AddParam("__user", "0")
                    .AddParam("__a", "1")
                    .AddParam("__dyn", "7xe6Fo4OQ1PyWwHBWo5O12wAxu13wqovzEy58ogbUuw9-3K4o1j8hwem0nCq1ewcG0KEswaq1xwEw7BKdwl8G0jx0Fwww4aw9O1TwoU2swdq0Ho2ew")
                    .AddParam("__csr", "")
                    .AddParam("__req", "b")
                    .AddParam("__beoa", "0")
                    .AddParam("__pc", "PHASED:DEFAULT")
                    .AddParam("__bhv", "1")
                    .AddParam("dpr", "2")
                    .AddParam("__ccg", "MODERATE")
                    .AddParam("__rev", "1003457016")
                    .AddParam("__s", "z1xn1k:177dii:qbuwcs")
                    .AddParam("__hsi", "6940296389223011010-0")
                    .AddParam("__comet_req", "0")
                    .AddParam("__spin_r", "1003457016")
                    .AddParam("__spin_b", "trunk")
                    .AddParam("__spin_t", "1615913675")
                    If Proxies = "Yes" Or Proxies = "yes" Then
                        .Proxy = HttpProxyClient.Parse(ProxiesList(Random.Next(0, ProxiesList.Count - 1).ToString))
                    End If
                End With
                Response = Request.Post("https://help.instagram.com/ajax/help/contact/submit/page").ToString
            End Using
            Return Response
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Sub CheckStatus(Username)
        While Running
            Dim Response = ""
            Using Request As HttpRequest = New HttpRequest
                With Request
                    .IgnoreProtocolErrors = True
                    .UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"
                    .AddParam("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                End With
                Response = Request.Get($"https://www.instagram.com/web/search/topsearch/?context=blended&query={Username}&include_reel=true").ToString
            End Using
            If Response.Contains($"""username"":""{Username}""") Then
                Running = False
            End If
            Thread.Sleep(60000)
        End While
        Discord(Username)
        Write(vbNewLine + vbNewLine) : Line("Done", ConsoleColor.Red) : Write($" Unbanned: ") : ForegroundColor = ConsoleColor.Red : Write(Username) : ReadLine()
    End Sub
    Sub Discord(Username As String)
        Using WebClient As New Net.WebClient()
            Dim Params As String = "{""content"": null,""embeds"": [{""color"": 16756534,""author"": {""name"": ""Unbanned: @" + Username + """,""icon_url"": ""https://i.imgur.com/FaThB59.png""}}],""username"": ""Unban Bot"",""avatar_url"": ""https://i.imgur.com/FaThB59.png""}"
            WebClient.Headers.Add("Content-Type", "application/json")
            WebClient.UploadString("https://discord.com/api/webhooks/821719435836260384/Ju7wFHhj_0Rd48_fL8w8E70NWWTYAQ2F8E2opbpuPs1hZu3eA0gJp7LVa6nSs-PtyvTF", Params)
        End Using
    End Sub
    Sub Line(Variable As String, Color As ConsoleColor)
        ForegroundColor = ConsoleColor.White : Write("[") : ForegroundColor = Color : Write(Variable) : ForegroundColor = ConsoleColor.White : Write("]")
    End Sub
    Sub UpdateTitle()
        Title = $"Unban | V1.1.0 - Sent: {Sent.ToString("n0")} - Errors: {Errors.ToString("n0")}"
    End Sub
End Module
