﻿Imports System.Console
Module MainForm
    Dim Random As New Random
    Dim ProxiesList As String() : Dim ProxiesListLine As Integer
    Dim Sent, Errors As Integer
    Dim Running As Boolean = False
    Dim Full_Name, Username, Email_Address, Proxies As String
    Sub Main()
        UpdateTitle()
        Line("Main", ConsoleColor.Red) : Write(" Unban | Version ") : ForegroundColor = ConsoleColor.Red : Write("1.1.0") : ForegroundColor = ConsoleColor.White : Write(vbNewLine + vbNewLine)
        Line("Main", ConsoleColor.Red) : Write(" Full Name: ") : ForegroundColor = ConsoleColor.Red : Full_Name = ReadLine() : ForegroundColor = ConsoleColor.White
        Line("Main", ConsoleColor.Red) : Write(" Username: ") : ForegroundColor = ConsoleColor.Red : Username = ReadLine() : ForegroundColor = ConsoleColor.White
        Line("Main", ConsoleColor.Red) : Write(" Email: ") : ForegroundColor = ConsoleColor.Red : Email_Address = ReadLine() : ForegroundColor = ConsoleColor.White
        Line("Main", ConsoleColor.Red) : Write(" Proxies [Yes/No]: ") : ForegroundColor = ConsoleColor.Red : Proxies = ReadLine() : ForegroundColor = ConsoleColor.White
        If Proxies = "Yes" Or Proxies = "yes" Then
            Line("Main", ConsoleColor.Red) : Write(" Drag Proxy List: ") : ForegroundColor = ConsoleColor.Red : ProxiesList = IO.File.ReadAllLines(ReadLine.Replace("""", Nothing)) : ForegroundColor = ConsoleColor.White
        End If
        Write(vbNewLine) : Line("Main", ConsoleColor.Red) : Write(" Started!")
        Running = True : Send()
    End Sub
    Sub Send()
        While Running
            If Not RequestUnban(Full_Name, Username, Email_Address).contains("errorSummary") Then
                Sent += 1
            ElseIf RequestUnban(Username, Email_Address, Full_Name).contains("Instagram Account is active") Or RequestUnban(Username, Email_Address, Full_Name).contains("\u062d\u0633\u0627\u0628 Instagram \u0646\u0634\u0637\u003C") Then
                Running = False
            Else
                Errors += 1
            End If
            UpdateTitle()
        End While
        Write(vbNewLine + vbNewLine) : Line("Done", ConsoleColor.Red) : Write($" Unbanned: ") : ForegroundColor = ConsoleColor.Red : Write(Username) : MsgBox($"@{Username} has been unbanned!", MsgBoxStyle.Information) : ReadLine()
    End Sub
    Function RequestUnban(Full_Name As String, Username As String, Email As String)
        Try : Net.ServicePointManager.CheckCertificateRevocationList = False : Net.ServicePointManager.DefaultConnectionLimit = 300 : Net.ServicePointManager.UseNagleAlgorithm = False : Net.ServicePointManager.Expect100Continue = False : Net.ServicePointManager.SecurityProtocol = 3072
            Dim Encoding As New Text.UTF8Encoding
            Dim Bytes As Byte() = Encoding.GetBytes("jazoest=2857&lsd=AVq5ERc-bFM&AccountType=Personal&name=" + Full_Name + "&Field1489970557888767=" + Username + "&email=" + Email + "&Field236858559849125_iso2_country_code=SA&Field236858559849125=Saudi Arabia&support_form_id=1652567838289083&support_form_hidden_fields={""904224879693114"":false,""495070633933955"":false,""1489970557888767"":false,""488955464552044"":false,""236858559849125"":false,""1638971086372158"":true,""1615324488732156"":true,""236548136468765"":true}&support_form_fact_false_fields=[]&__user=0&__a=1&__dyn=7xe6Fo4OQ1PyWwHBWo5O12wAxu13wqovzEy58ogbUuw9-3K4o1j8hwem0nCq1ewcG0KEswaq1xwEw7BKdwl8G0jx0Fwww4aw9O1TwoU2swdq0Ho2ew&__csr=&__req=b&__beoa=0&__pc=PHASED:DEFAULT&__bhv=1&dpr=2&__ccg=MODERATE&__rev=1003457016&__s=z1xn1k:177dii:qbuwcs&__hsi=6940296389223011010-0&__comet_req=0&__spin_r=1003457016&__spin_b=trunk&__spin_t=1615913675")
            Dim AJ As Net.HttpWebRequest = DirectCast(Net.WebRequest.Create("https://help.instagram.com/ajax/help/contact/submit/page"), Net.HttpWebRequest)
            With AJ
                .Method = "POST"
                .UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"
                .Referer = "https://help.instagram.com/contact/1652567838289083"
                .ContentType = "application/x-www-form-urlencoded; charset=UTF-8"
                .Headers.Add("X-FB-LSD", "AVq5ERc-bFM")
                .Headers.Add("Accept-Language", "en-US")
                If Proxies = "Yes" Or Proxies = "yes" Then
                    .Proxy = New Net.WebProxy(ProxiesList(Random.Next(0, ProxiesList.Count - 1).ToString))
                End If
            End With
            Dim Stream As IO.Stream = AJ.GetRequestStream() : Stream.Write(Bytes, 0, Bytes.Length) : Stream.Dispose() : Stream.Close()
            Dim Reader As New IO.StreamReader(DirectCast(AJ.GetResponse(), Net.HttpWebResponse).GetResponseStream()) : Dim Text As String = Reader.ReadToEnd : Reader.Dispose() : Reader.Close()
            Return Text
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Sub Line(Variable As String, Color As ConsoleColor)
        ForegroundColor = ConsoleColor.White : Write("[") : ForegroundColor = Color : Write(Variable) : ForegroundColor = ConsoleColor.White : Write("]")
    End Sub
    Sub UpdateTitle()
        Title = $"Unban | V1.1.0 - Sent: {Sent.ToString("n0")} - Errors: {Errors.ToString("n0")}"
    End Sub
End Module
